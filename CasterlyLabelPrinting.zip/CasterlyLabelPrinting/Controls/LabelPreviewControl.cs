using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using CasterlyLabelPrinting.Models;
using CasterlyLabelPrinting.Rendering;

namespace CasterlyLabelPrinting.Controls
{
    /// <summary>
    /// Live preview surface used by "View Label". Automatically scales the
    /// label to fill the control while preserving its true aspect ratio, and
    /// reuses the exact same drawing code the print job uses.
    /// </summary>
    public class LabelPreviewControl : Control
    {
        private LabelDesign _design;
        private LabelFieldData _data;

        public LabelPreviewControl()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);
            BackColor = Color.WhiteSmoke;
        }

        /// <summary>Sets (or clears, if either argument is null) what to preview, and repaints.</summary>
        public void SetContent(LabelDesign design, LabelFieldData data)
        {
            _design = design;
            _data = data;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (_design == null || _data == null)
            {
                using var msgFont = new Font("Segoe UI", 9f);
                TextRenderer.DrawText(
                    e.Graphics,
                    "Enter a Service-Tag or LOT-Number, then click \"View Label\".",
                    msgFont,
                    ClientRectangle,
                    Color.Gray,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
                return;
            }

            float labelWidthIn = _design.WidthHundredthInch / 100f;
            float labelHeightIn = _design.HeightHundredthInch / 100f;

            const int margin = 12;
            float availW = Math.Max(10, Width - margin * 2);
            float availH = Math.Max(10, Height - margin * 2);

            // Choose the largest uniform zoom that lets the label fit entirely
            // within the available area (letterboxed on whichever axis has spare room).
            float zoomForWidth = availW / (labelWidthIn * e.Graphics.DpiX);
            float zoomForHeight = availH / (labelHeightIn * e.Graphics.DpiY);
            float zoom = Math.Min(zoomForWidth, zoomForHeight);

            float renderedWidthPx = labelWidthIn * e.Graphics.DpiX * zoom;
            float renderedHeightPx = labelHeightIn * e.Graphics.DpiY * zoom;
            float offsetX = (Width - renderedWidthPx) / 2f;
            float offsetY = (Height - renderedHeightPx) / 2f;

            GraphicsState state = e.Graphics.Save();
            try
            {
                e.Graphics.TranslateTransform(offsetX, offsetY);
                LabelRenderer.Draw(e.Graphics, _design, _data, zoom);
            }
            finally
            {
                e.Graphics.Restore(state);
            }
        }
    }
}
