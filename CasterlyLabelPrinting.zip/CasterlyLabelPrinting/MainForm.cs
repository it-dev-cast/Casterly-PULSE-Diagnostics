using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using CasterlyLabelPrinting.Controls;
using CasterlyLabelPrinting.Models;
using CasterlyLabelPrinting.Services;

namespace CasterlyLabelPrinting
{
    /// <summary>
    /// The "Casterly Label Printing" screen: Service-Tag / LOT-Number lookup
    /// (autocompleted from Supabase), a live label preview, and a Print action
    /// that exports an Excel snapshot and then prints directly.
    /// </summary>
    public class MainForm : Form
    {
        private readonly SupabaseService _supabase = new();
        private LabelDesign _design;

        private readonly System.Windows.Forms.Timer _serviceTagDebounce;
        private readonly System.Windows.Forms.Timer _lotDebounce;
        private bool _suppressTextEvents;

        // -- UI controls --
        private PictureBox picLogo;
        private Label lblCaption;
        private TextBox txtServiceTag;
        private TextBox txtLotNumber;
        private Button btnViewLabel;
        private Button btnPrintLabel;
        private LabelPreviewControl labelPreview;
        private Label lblStatus;

        public MainForm()
        {
            InitializeComponent();

            _serviceTagDebounce = new System.Windows.Forms.Timer { Interval = 300 };
            _serviceTagDebounce.Tick += async (s, e) =>
            {
                _serviceTagDebounce.Stop();
                await RefreshServiceTagSuggestionsAsync();
            };

            _lotDebounce = new System.Windows.Forms.Timer { Interval = 300 };
            _lotDebounce.Tick += async (s, e) =>
            {
                _lotDebounce.Stop();
                await RefreshLotSuggestionsAsync();
            };

            LoadLabelDesign();
        }

        // ---------------- Label design loading ----------------

        private void LoadLabelDesign()
        {
            try
            {
                string path = Path.Combine(AppContext.BaseDirectory, "Resources", "LabelBoxLive.yix");
                _design = YixLabelParser.Load(path);
                string printerNote = string.IsNullOrWhiteSpace(_design.PreferredPrinterName)
                    ? "none specified"
                    : _design.PreferredPrinterName;
                SetStatus($"Label design loaded ({_design.Items.Count} fields). Preferred printer: {printerNote}.");
            }
            catch (Exception ex)
            {
                _design = null;
                MessageBox.Show(
                    this,
                    $"Could not load the label design (Resources\\LabelBoxLive.yix):\n\n{ex.Message}",
                    "Casterly Label Printing",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                SetStatus("Label design failed to load — View Label / Print Label are unavailable.");
            }
        }

        private void SetStatus(string text)
        {
            if (lblStatus.InvokeRequired)
            {
                lblStatus.Invoke(new Action(() => lblStatus.Text = text));
                return;
            }
            lblStatus.Text = text;
        }

        // ---------------- Autocomplete ----------------

        private void TxtServiceTag_TextChanged(object sender, EventArgs e)
        {
            if (_suppressTextEvents) return;

            if (txtServiceTag.Text.Length > 0 && txtLotNumber.Text.Length > 0)
            {
                _suppressTextEvents = true;
                txtLotNumber.Clear();
                _suppressTextEvents = false;
            }

            _serviceTagDebounce.Stop();
            _serviceTagDebounce.Start();
        }

        private void TxtLotNumber_TextChanged(object sender, EventArgs e)
        {
            if (_suppressTextEvents) return;

            if (txtLotNumber.Text.Length > 0 && txtServiceTag.Text.Length > 0)
            {
                _suppressTextEvents = true;
                txtServiceTag.Clear();
                _suppressTextEvents = false;
            }

            _lotDebounce.Stop();
            _lotDebounce.Start();
        }

        private async Task RefreshServiceTagSuggestionsAsync()
        {
            string query = txtServiceTag.Text.Trim();
            if (query.Length < 2) return;

            try
            {
                List<string> matches = await _supabase.SearchSerialNumbersAsync(query);
                var source = new AutoCompleteStringCollection();
                source.AddRange(matches.ToArray());
                txtServiceTag.AutoCompleteCustomSource = source;
            }
            catch (Exception ex)
            {
                SetStatus("Serial number lookup failed: " + ex.Message);
            }
        }

        private async Task RefreshLotSuggestionsAsync()
        {
            string query = txtLotNumber.Text.Trim();
            if (query.Length < 2) return;

            try
            {
                List<string> matches = await _supabase.SearchLotNamesAsync(query);
                var source = new AutoCompleteStringCollection();
                source.AddRange(matches.ToArray());
                txtLotNumber.AutoCompleteCustomSource = source;
            }
            catch (Exception ex)
            {
                SetStatus("LOT name lookup failed: " + ex.Message);
            }
        }

        // ---------------- View Label ----------------

        private async void BtnViewLabel_Click(object sender, EventArgs e)
        {
            if (_design == null)
            {
                MessageBox.Show(this, "The label design failed to load; see the status bar for details.",
                    "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SetBusy(true);
            try
            {
                List<LabelFieldData> records = await BuildRecordsFromInputAsync();
                if (records == null || records.Count == 0)
                    return; // BuildRecordsFromInputAsync already showed a message.

                // The preview always shows the first record. For a LOT that's
                // the earliest-inspected unit; Print will still cover all of them.
                labelPreview.SetContent(_design, records[0]);
                SetStatus(records.Count == 1
                    ? "Showing preview for 1 record."
                    : $"Showing preview for the first of {records.Count} records in this LOT.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Could not build the label preview:\n\n{ex.Message}",
                    "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SetStatus("Preview failed: " + ex.Message);
            }
            finally
            {
                SetBusy(false);
            }
        }

        // ---------------- Print Label ----------------

        private async void BtnPrintLabel_Click(object sender, EventArgs e)
        {
            if (_design == null)
            {
                MessageBox.Show(this, "The label design failed to load; see the status bar for details.",
                    "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SetBusy(true);
            try
            {
                List<LabelFieldData> records = await BuildRecordsFromInputAsync();
                if (records == null || records.Count == 0)
                    return;

                labelPreview.SetContent(_design, records[0]);

                bool isLotMode = txtLotNumber.Text.Trim().Length > 0;
                string baseName = isLotMode
                    ? $"LOT_{txtLotNumber.Text.Trim()}"
                    : $"ServiceTag_{txtServiceTag.Text.Trim()}";

                // Step 1: generate the Excel export on the local system.
                string excelPath = ExcelExportService.Export(records, baseName);
                SetStatus($"Excel generated: {excelPath}");

                // Step 2: send the print job (one label per record) to the printer.
                var printService = new LabelPrintService(_design);
                printService.Print(records, _design.PreferredPrinterName);

                SetStatus($"Printed {records.Count} label(s). Excel saved to: {excelPath}");
                MessageBox.Show(
                    this,
                    $"Printed {records.Count} label(s).\n\nExcel export saved to:\n{excelPath}",
                    "Casterly Label Printing",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Print failed:\n\n{ex.Message}",
                    "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SetStatus("Print failed: " + ex.Message);
            }
            finally
            {
                SetBusy(false);
            }
        }

        /// <summary>
        /// Resolves the current Service-Tag / LOT-Number input into the list
        /// of LabelFieldData records to preview/print: the single latest
        /// record for a Service-Tag, or every unit in the LOT for a
        /// LOT-Number. Shows its own message box and returns null on empty or
        /// not-found input.
        /// </summary>
        private async Task<List<LabelFieldData>> BuildRecordsFromInputAsync()
        {
            string serial = txtServiceTag.Text.Trim();
            string lot = txtLotNumber.Text.Trim();

            if (serial.Length == 0 && lot.Length == 0)
            {
                MessageBox.Show(this, "Enter a Service-Tag or a LOT-Number first.",
                    "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            if (serial.Length > 0)
            {
                SetStatus($"Looking up the latest inspection for serial \"{serial}\"...");
                InspectionRow inspection = await _supabase.GetLatestInspectionBySerialAsync(serial);
                if (inspection == null)
                {
                    MessageBox.Show(this, $"No inspection record found for Service-Tag \"{serial}\".",
                        "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return null;
                }

                LabelFieldData data = await _supabase.BuildLabelFieldDataAsync(inspection);
                return new List<LabelFieldData> { data };
            }
            else
            {
                SetStatus($"Looking up all inspections for LOT \"{lot}\"...");
                List<InspectionRow> inspections = await _supabase.GetInspectionsByLotAsync(lot);
                if (inspections.Count == 0)
                {
                    MessageBox.Show(this, $"No inspection records found for LOT-Number \"{lot}\".",
                        "Casterly Label Printing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return null;
                }

                var results = new List<LabelFieldData>();
                foreach (InspectionRow insp in inspections)
                    results.Add(await _supabase.BuildLabelFieldDataAsync(insp));
                return results;
            }
        }

        private void SetBusy(bool busy)
        {
            Cursor = busy ? Cursors.WaitCursor : Cursors.Default;
            btnViewLabel.Enabled = !busy;
            btnPrintLabel.Enabled = !busy;
            txtServiceTag.Enabled = !busy;
            txtLotNumber.Enabled = !busy;
        }

        // ---------------- Layout (built entirely in code) ----------------

        private void InitializeComponent()
        {
            SuspendLayout();

            Text = "Casterly Label Printing";
            Font = new Font("Segoe UI", 9f);
            ClientSize = new Size(920, 660);
            MinimumSize = new Size(780, 580);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.WhiteSmoke;

            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));

            // ---- Header: Casterly logo + caption ----
            var headerPanel = new Panel { Dock = DockStyle.Fill, BackColor = ColorTranslator.FromHtml("#0B2545") };

            picLogo = new PictureBox
            {
                Location = new Point(16, 8),
                Size = new Size(140, 56),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.White
            };
            TryLoadLogo();

            lblCaption = new Label
            {
                AutoSize = false,
                Location = new Point(168, 0),
                Size = new Size(720, 72),
                Text = "Casterly Label Printing and Reporting",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };

            headerPanel.Controls.Add(picLogo);
            headerPanel.Controls.Add(lblCaption);

            // ---- Inputs: Service-Tag / LOT-Number / action buttons ----
            var inputPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 3,
                Padding = new Padding(20, 12, 20, 8)
            };
            inputPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
            inputPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            inputPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            inputPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            inputPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 34));

            var lblServiceTag = new Label
            {
                Text = "\U0001F3F7  Service-Tag", // 🏷
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold)
            };
            txtServiceTag = new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10f),
                AutoCompleteMode = AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = AutoCompleteSource.CustomSource,
                AutoCompleteCustomSource = new AutoCompleteStringCollection()
            };
            txtServiceTag.TextChanged += TxtServiceTag_TextChanged;

            var lblLot = new Label
            {
                Text = "\U0001F4E6  LOT-Number", // 📦
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold)
            };
            txtLotNumber = new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10f),
                AutoCompleteMode = AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = AutoCompleteSource.CustomSource,
                AutoCompleteCustomSource = new AutoCompleteStringCollection()
            };
            txtLotNumber.TextChanged += TxtLotNumber_TextChanged;

            var buttonFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };

            btnViewLabel = new Button
            {
                Text = "\U0001F441  View Label", // 👁
                AutoSize = true,
                Padding = new Padding(14, 8, 14, 8),
                Font = new Font("Segoe UI", 10f),
                BackColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnViewLabel.Click += BtnViewLabel_Click;

            btnPrintLabel = new Button
            {
                Text = "\U0001F5A8  Print Label", // 🖨
                AutoSize = true,
                Padding = new Padding(14, 8, 14, 8),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                BackColor = ColorTranslator.FromHtml("#0B2545"),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(12, 0, 0, 0)
            };
            btnPrintLabel.Click += BtnPrintLabel_Click;

            buttonFlow.Controls.Add(btnViewLabel);
            buttonFlow.Controls.Add(btnPrintLabel);

            inputPanel.Controls.Add(lblServiceTag, 0, 0);
            inputPanel.Controls.Add(txtServiceTag, 1, 0);
            inputPanel.Controls.Add(lblLot, 0, 1);
            inputPanel.Controls.Add(txtLotNumber, 1, 1);
            inputPanel.Controls.Add(buttonFlow, 1, 2);

            // ---- Preview ----
            var grpPreview = new GroupBox
            {
                Text = "Label Preview",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Padding = new Padding(12),
                Margin = new Padding(20, 4, 20, 4)
            };
            labelPreview = new LabelPreviewControl { Dock = DockStyle.Fill };
            grpPreview.Controls.Add(labelPreview);

            // ---- Status bar ----
            lblStatus = new Label
            {
                Dock = DockStyle.Fill,
                Text = "Ready.",
                ForeColor = Color.DimGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(20, 0, 0, 0),
                BackColor = Color.Gainsboro
            };

            root.Controls.Add(headerPanel, 0, 0);
            root.Controls.Add(inputPanel, 0, 1);
            root.Controls.Add(grpPreview, 0, 2);
            root.Controls.Add(lblStatus, 0, 3);

            Controls.Add(root);

            ResumeLayout(false);
        }

        private void TryLoadLogo()
        {
            try
            {
                string path = Path.Combine(AppContext.BaseDirectory, "Resources", "casterly_logo.png");
                if (File.Exists(path))
                    picLogo.Image = Image.FromFile(path);
            }
            catch
            {
                // Non-fatal — the header still shows the caption without the logo.
            }
        }
    }
}
