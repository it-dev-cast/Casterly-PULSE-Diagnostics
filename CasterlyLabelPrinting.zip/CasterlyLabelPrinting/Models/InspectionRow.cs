using System.Text.Json;

namespace CasterlyLabelPrinting.Models
{
    /// <summary>A raw row from tbl_pulse_inspections (only the columns this app needs).</summary>
    public class InspectionRow
    {
        public string Uuid { get; set; }
        public string SerialNumber { get; set; }
        public string LotName { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string InspectionTimestamp { get; set; }

        public static InspectionRow FromJson(JsonElement e)
        {
            string GetStr(string name) =>
                e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

            return new InspectionRow
            {
                Uuid = GetStr("uuid"),
                SerialNumber = GetStr("serial_number"),
                LotName = GetStr("lot_name"),
                Manufacturer = GetStr("manufacturer"),
                Model = GetStr("model"),
                InspectionTimestamp = GetStr("inspection_timestamp")
            };
        }
    }
}
