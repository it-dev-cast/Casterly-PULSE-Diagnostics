using System.Collections.Generic;
using System.Drawing;

namespace CasterlyLabelPrinting.Models
{
    /// <summary>One static or data-bound text item on the label, parsed from the .yix file.</summary>
    public class LabelTextItem
    {
        /// <summary>True if this item's text comes from a data column (e.g. the value next to "Manufacturer"); false for the static caption text itself.</summary>
        public bool IsDataBound { get; set; }

        /// <summary>The literal caption text, when <see cref="IsDataBound"/> is false.</summary>
        public string StaticText { get; set; } = "";

        /// <summary>The bound column name (e.g. "Serial No."), when <see cref="IsDataBound"/> is true.</summary>
        public string DataSourceColumn { get; set; } = "";

        /// <summary>Position/size in hundredths of an inch — the .yix file's native unit.</summary>
        public RectangleF RectHundredthInch { get; set; }

        public string FontFamily { get; set; } = "Arial";
        public float FontSizePt { get; set; } = 8f;
        public bool Bold { get; set; }
        public StringAlignment Alignment { get; set; } = StringAlignment.Center;
    }

    /// <summary>The full label layout, parsed from a .yix label design file.</summary>
    public class LabelDesign
    {
        /// <summary>Label width/height in hundredths of an inch.</summary>
        public float WidthHundredthInch { get; set; } = 393.7f;
        public float HeightHundredthInch { get; set; } = 196.85f;

        /// <summary>The printer name recorded in the label design (e.g. "TSC TE244"), used as a hint — not a hard requirement.</summary>
        public string PreferredPrinterName { get; set; } = "";

        /// <summary>Column names the design expects, in the order the original label software displayed them.</summary>
        public List<string> DataColumns { get; set; } = new();

        public List<LabelTextItem> Items { get; set; } = new();
    }
}
