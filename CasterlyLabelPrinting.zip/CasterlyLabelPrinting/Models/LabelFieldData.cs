namespace CasterlyLabelPrinting.Models
{
    /// <summary>
    /// The 7 fields printed on the physical label, matching the column names
    /// used by LabelBoxLive.yix's data source: Manufacturer, Model,
    /// "Serial No.", Processor, Memory, "Storage Type", "Storage Capacity".
    /// </summary>
    public class LabelFieldData
    {
        public string Manufacturer { get; set; } = "-";
        public string Model { get; set; } = "-";
        public string SerialNo { get; set; } = "-";
        public string Processor { get; set; } = "-";
        public string Memory { get; set; } = "-";
        public string StorageType { get; set; } = "-";
        public string StorageCapacity { get; set; } = "-";

        /// <summary>Looks a field up by the exact column name used in the .yix (e.g. "Serial No.").</summary>
        public string GetByColumnName(string column)
        {
            return column switch
            {
                "Manufacturer" => Manufacturer,
                "Model" => Model,
                "Serial No." => SerialNo,
                "Processor" => Processor,
                "Memory" => Memory,
                "Storage Type" => StorageType,
                "Storage Capacity" => StorageCapacity,
                _ => "-"
            };
        }
    }
}
