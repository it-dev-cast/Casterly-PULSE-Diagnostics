using System;
using System.Windows.Forms;

namespace CasterlyLabelPrinting
{
    /// <summary>Application entry point.</summary>
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Catch anything unhandled on the UI thread so the app shows a
            // message instead of silently crashing (PRD requirement: handle
            // errors gracefully).
            Application.ThreadException += (sender, e) =>
            {
                MessageBox.Show(
                    "An unexpected error occurred:\n\n" + e.Exception.Message,
                    "Casterly Label Printing",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            };

            AppDomain.CurrentDomain.UnhandledException += (sender, e) =>
            {
                MessageBox.Show(
                    "A fatal error occurred:\n\n" + (e.ExceptionObject as Exception)?.Message,
                    "Casterly Label Printing",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            };

            Application.Run(new MainForm());
        }
    }
}
