# Casterly Label Printing

A standalone Windows desktop app (C#, .NET 6, WinForms) for looking up a
device's inspection record in Supabase by Service-Tag or LOT-Number, previewing
its label, and printing it directly to a label printer (e.g. a TSC TE244).

This is a new, self-contained project — it does not touch or depend on the
existing PULSE inspection application in any way.

## Important: this was built without a Windows/.NET environment

This project was written and reviewed in a Linux sandbox with no internet
access to nuget.org and no Windows machine available, so **it has not been
compiled or run**. Every file was hand-written and manually checked (brace
balance, using-directives, API signatures), but the very first thing to do is
open it in Visual Studio and build it — if anything doesn't compile, send me
the error text and I'll fix it immediately.

## What it does

1. Header: Casterly logo + "Casterly Label Printing and Reporting" caption.
2. **Service-Tag** field — type a few characters and matching serial numbers
   (from `tbl_pulse_inspections.serial_number`) appear as autocomplete
   suggestions.
3. **LOT-Number** field — same idea, against `tbl_pulse_inspections.lot_name`.
   Only one of the two fields can be filled at a time (filling one clears the
   other).
4. **View Label** — looks up the record(s) in Supabase and renders a live,
   true-to-layout preview of the label using the geometry parsed straight out
   of `Resources\LabelBoxLive.yix` (position, font, alignment of every field).
5. **Print Label**:
   - Service-Tag mode: takes the **most recent** inspection for that serial
     number, exports it to Excel, and prints **one** label.
   - LOT-Number mode: takes **every** inspection under that LOT, exports all
     of them to one Excel file, and prints **one label per unit**.

The app renders and prints the label itself (matching the `.yix` design's
exact field positions, fonts, and alignment) — it does not require the
original WageLabel/label-editor software to be installed on the machine that
prints.

## Project layout

```
CasterlyLabelPrinting/
  CasterlyLabelPrinting.sln
  CasterlyLabelPrinting.csproj
  Program.cs                     Entry point
  MainForm.cs                    The screen: header, inputs, preview, buttons
  Models/
    LabelFieldData.cs            The 7 label fields
    InspectionRow.cs             Raw tbl_pulse_inspections row
    LabelDesign.cs               Parsed .yix layout (positions/fonts/etc.)
  Services/
    SupabaseConfig.cs            Supabase URL + service role key (see Security below)
    SupabaseService.cs           REST calls to Supabase (search + lookups + joins)
    YixLabelParser.cs            Parses LabelBoxLive.yix into a LabelDesign
    ExcelExportService.cs        Builds the "Device Details" .xlsx export
    LabelPrintService.cs         Sends the print job to the printer
  Rendering/
    LabelRenderer.cs             Shared drawing code (preview + print use this)
  Controls/
    LabelPreviewControl.cs       The "View Label" preview panel
  Resources/
    LabelBoxLive.yix             The label design (as supplied)
    casterly_logo.png            Header logo
  installer/
    CasterlyLabelPrinting.iss    Inno Setup script (see Building an installer)
```

## Prerequisites

- Windows 10/11
- Visual Studio 2022 or later (Visual Studio 2026 once available) with the
  ".NET Desktop Development" workload, **or** just the .NET 6 SDK (or later)
  and any text editor
- Internet access on the build machine (NuGet needs to fetch the `ClosedXML`
  package and the Windows Desktop reference assemblies)
- A printer installed in Windows — either the label printer named in the
  `.yix` file (e.g. "TSC TE244") or any default printer, for testing

## Building and running

```bash
cd CasterlyLabelPrinting
dotnet restore
dotnet build
dotnet run
```

Or just open `CasterlyLabelPrinting.sln` in Visual Studio, let it restore
NuGet packages, and press F5.

## How printing works

- On **Print Label**, the app first writes an Excel file to
  `Documents\Casterly Label Printing\` (e.g.
  `ServiceTag_1ZNYRQ3_20260707_143210.xlsx` or `LOT_LOT-004_....xlsx`), with a
  "Device Details" sheet and the same column headers/order the `.yix` design
  was built against (Manufacturer, Model, Serial No., Processor, Memory,
  Storage Type, Storage Capacity).
- It then prints directly: one label per row, using the exact positions/fonts
  parsed from `LabelBoxLive.yix`, sized to the label's real dimensions (100mm
  x 50mm, from the `.yix`'s `LabelSize`).
- Printer selection: if a printer named exactly like the one recorded in the
  `.yix` (e.g. "TSC TE244") is installed on the machine, that's used;
  otherwise it falls back to Windows' current default printer. You'll see
  which one was used in the status bar.
- If you'd rather always force a specific printer regardless of what's
  installed, that's a one-line change in `LabelPrintService.Print(...)`.

## Data lookup logic

- **Service-Tag**: `tbl_pulse_inspections` filtered by exact
  `serial_number`, ordered by `inspection_timestamp` descending, `limit 1` —
  i.e. the latest inspection for that unit.
- **LOT-Number**: every `tbl_pulse_inspections` row with that exact
  `lot_name`.
- For each inspection row, Processor / Memory / Storage Type / Storage
  Capacity are joined in from `tbl_pulse_cpu_info`, `tbl_pulse_memory_info`,
  and `tbl_pulse_storage_info` via the inspection's `uuid`. Manufacturer,
  Model, and Serial No. come directly off the inspection row.

## Security note on the Supabase credentials

`Services/SupabaseConfig.cs` hardcodes the Supabase URL and **service role
key** you provided. The service role key bypasses Row Level Security
entirely — anyone with a copy of the compiled .exe can extract this string
and get full read/write access to every table in the project. That's fine for
an internal, trusted tool, but if this app is ever going to leave a small
trusted group of machines, consider:

- Moving the key to an environment variable or Windows Credential Manager
  instead of compiling it into the binary, and/or
- Routing requests through a small backend/proxy that uses a scoped API key
  instead of the service role key directly.

## Building an installer

I can't produce a compiled installer from this environment (no Windows, no
network access to the .NET toolchain). Instead, `installer/CasterlyLabelPrinting.iss`
is a ready-to-use [Inno Setup](https://jrsoftware.org/isdl.php) script (Inno
Setup is free). On a Windows machine with the SDK installed:

```bash
cd CasterlyLabelPrinting
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish
```

Then open `installer/CasterlyLabelPrinting.iss` in the Inno Setup Compiler
(or run `ISCC.exe CasterlyLabelPrinting.iss`) to produce
`installer/Output/CasterlyLabelPrintingSetup.exe` — a normal double-click
installer with a desktop shortcut option.

## Known limitations / things to sanity-check on real hardware

- The custom label paper size is set from the `.yix`'s dimensions
  (100mm x 50mm). Some printer drivers require a matching paper size to
  already exist in the driver's own settings rather than accepting an
  arbitrary custom size from the app — if printing comes out blank or errors,
  check the printer driver's paper/media configuration first.
- Storage: if a device has more than one drive, only the first (by
  `drive_index`) is shown, matching the label's single Storage Type/Capacity
  fields.
- Autocomplete triggers after 2+ characters, debounced 300ms, showing up to
  10 matches at a time.
