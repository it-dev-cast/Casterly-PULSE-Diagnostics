using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using CasterlyLabelPrinting.Models;

namespace CasterlyLabelPrinting.Rendering
{
    /// <summary>
    /// Draws a LabelDesign + LabelFieldData combination onto any Graphics
    /// surface. Shared by both the on-screen preview and the physical print
    /// job, so what "View Label" shows is exactly what "Print Label" produces.
    /// </summary>
    public static class LabelRenderer
    {
        /// <param name="zoom">
        /// Uniform scale for the whole label. Use 1.0 for true physical size
        /// (printing). Use a larger value to enlarge the label for on-screen
        /// viewing.
        /// </param>
        public static void Draw(Graphics g, LabelDesign design, LabelFieldData data, float zoom)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            // Working in inches keeps every coordinate a direct, obvious
            // conversion from the .yix file's native "hundredths of an inch"
            // units (just divide by 100); PageScale then uniformly enlarges
            // everything (including text) for on-screen viewing without
            // needing separate DPI math for fonts vs. shapes.
            g.PageUnit = GraphicsUnit.Inch;
            g.PageScale = zoom;

            var labelRect = new RectangleF(0, 0, design.WidthHundredthInch / 100f, design.HeightHundredthInch / 100f);
            using (var bg = new SolidBrush(Color.White))
                g.FillRectangle(bg, labelRect);
            using (var border = new Pen(Color.Gainsboro, 0.01f))
                g.DrawRectangle(border, labelRect.X, labelRect.Y, labelRect.Width, labelRect.Height);

            foreach (LabelTextItem item in design.Items)
            {
                var rect = new RectangleF(
                    item.RectHundredthInch.X / 100f,
                    item.RectHundredthInch.Y / 100f,
                    item.RectHundredthInch.Width / 100f,
                    item.RectHundredthInch.Height / 100f);

                string text = item.IsDataBound ? data.GetByColumnName(item.DataSourceColumn) : item.StaticText;
                if (string.IsNullOrEmpty(text))
                    text = "-";

                FontStyle style = item.Bold ? FontStyle.Bold : FontStyle.Regular;
                using var font = new Font(item.FontFamily, item.FontSizePt, style, GraphicsUnit.Point);
                using var brush = new SolidBrush(Color.Black);
                using var format = new StringFormat
                {
                    Alignment = item.Alignment,
                    LineAlignment = StringAlignment.Center,
                    Trimming = StringTrimming.EllipsisCharacter,
                    FormatFlags = StringFormatFlags.NoWrap
                };

                g.DrawString(text, font, brush, rect, format);
            }
        }
    }
}
