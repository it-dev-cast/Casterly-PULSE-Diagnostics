using System;
using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;
using CasterlyLabelPrinting.Models;

namespace CasterlyLabelPrinting.Services
{
    /// <summary>
    /// Builds the "Device Details" Excel export (one row per device) — always
    /// generated first, before every print job — using the exact column
    /// names/order the .yix label design's data source was built against:
    /// Manufacturer, Model, Serial No., Processor, Memory, Storage Type, Storage Capacity.
    /// </summary>
    public static class ExcelExportService
    {
        public static readonly string[] ColumnHeaders =
        {
            "Manufacturer", "Model", "Serial No.", "Processor", "Memory", "Storage Type", "Storage Capacity"
        };

        /// <summary>Writes the workbook to Documents\Casterly Label Printing\ and returns the full file path.</summary>
        public static string Export(IReadOnlyList<LabelFieldData> rows, string fileNameWithoutExtension)
        {
            if (rows == null || rows.Count == 0)
                throw new InvalidOperationException("No records to export.");

            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "Casterly Label Printing");
            Directory.CreateDirectory(folder);

            string safeName = MakeSafeFileName(fileNameWithoutExtension);
            string path = Path.Combine(folder, $"{safeName}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");

            using (var wb = new XLWorkbook())
            {
                var ws = wb.Worksheets.Add("Device Details");

                for (int c = 0; c < ColumnHeaders.Length; c++)
                {
                    var cell = ws.Cell(1, c + 1);
                    cell.Value = ColumnHeaders[c];
                    cell.Style.Font.Bold = true;
                    cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#0B2545");
                    cell.Style.Font.FontColor = XLColor.White;
                }

                for (int r = 0; r < rows.Count; r++)
                {
                    LabelFieldData row = rows[r];
                    ws.Cell(r + 2, 1).Value = row.Manufacturer;
                    ws.Cell(r + 2, 2).Value = row.Model;
                    ws.Cell(r + 2, 3).Value = row.SerialNo;
                    ws.Cell(r + 2, 4).Value = row.Processor;
                    ws.Cell(r + 2, 5).Value = row.Memory;
                    ws.Cell(r + 2, 6).Value = row.StorageType;
                    ws.Cell(r + 2, 7).Value = row.StorageCapacity;
                }

                ws.Columns().AdjustToContents();
                wb.SaveAs(path);
            }

            return path;
        }

        private static string MakeSafeFileName(string name)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }
    }
}
