using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using CasterlyLabelPrinting.Models;
using CasterlyLabelPrinting.Rendering;

namespace CasterlyLabelPrinting.Services
{
    /// <summary>
    /// Prints one label per record directly, using the same LabelRenderer the
    /// on-screen preview uses (no dependency on the original label-editor
    /// software / .yix reader being installed on the print machine).
    /// </summary>
    public class LabelPrintService
    {
        private readonly LabelDesign _design;

        public LabelPrintService(LabelDesign design)
        {
            _design = design ?? throw new ArgumentNullException(nameof(design));
        }

        /// <summary>
        /// Prints one label per entry in <paramref name="records"/>.
        /// Uses <paramref name="preferredPrinterName"/> (the printer named in the
        /// .yix design, e.g. "TSC TE244") if it's installed on this machine;
        /// otherwise falls back to Windows' current default printer.
        /// </summary>
        public void Print(IReadOnlyList<LabelFieldData> records, string preferredPrinterName)
        {
            if (records == null || records.Count == 0)
                throw new InvalidOperationException("Nothing to print.");

            using var doc = new PrintDocument();

            bool usedPreferred = false;
            if (!string.IsNullOrWhiteSpace(preferredPrinterName))
            {
                bool installed = PrinterSettings.InstalledPrinters
                    .Cast<string>()
                    .Any(p => string.Equals(p, preferredPrinterName, StringComparison.OrdinalIgnoreCase));
                if (installed)
                {
                    doc.PrinterSettings.PrinterName = preferredPrinterName;
                    usedPreferred = true;
                }
            }
            // If not using the preferred printer, PrintDocument already
            // defaults PrinterSettings.PrinterName to Windows' default printer.

            if (!doc.PrinterSettings.IsValid)
            {
                string tried = usedPreferred ? preferredPrinterName : "the Windows default printer";
                throw new InvalidOperationException(
                    $"No usable printer found (tried {tried}). Check that a printer is installed " +
                    "and set as default in Windows (Settings > Printers & scanners).");
            }

            // Custom paper size matching the label design (PaperSize's width/height
            // are natively in hundredths of an inch, the same unit the .yix uses).
            doc.DefaultPageSettings.PaperSize = new PaperSize(
                "Casterly Label",
                (int)Math.Round(_design.WidthHundredthInch),
                (int)Math.Round(_design.HeightHundredthInch));
            doc.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);

            int index = 0;
            doc.PrintPage += (sender, e) =>
            {
                LabelFieldData record = records[index];
                LabelRenderer.Draw(e.Graphics, _design, record, zoom: 1f);

                index++;
                e.HasMorePages = index < records.Count;
            };

            doc.Print();
        }
    }
}
