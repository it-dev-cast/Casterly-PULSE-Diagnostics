namespace CasterlyLabelPrinting.Services
{
    /// <summary>
    /// Supabase connection settings for the "Renew" project's PostgREST API.
    ///
    /// SECURITY NOTE: the service role key below bypasses Row Level Security
    /// entirely (it has full read/write access to every table). It is
    /// hardcoded here only because it was supplied directly for this internal
    /// tool. For a wider rollout, prefer pulling it from an environment
    /// variable, Windows Credential Manager, or a small proxy API instead of
    /// shipping it inside the .exe, since anyone with the binary can extract
    /// this string.
    /// </summary>
    public static class SupabaseConfig
    {
        public const string SupabaseUrl = "https://pesgdrfeauofhtbjqkbz.supabase.co";

        public const string ServiceRoleKey =
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBlc2dkcmZlYXVvZmh0Ympxa2J6Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NzgwNjg5NywiZXhwIjoyMDkzMzgyODk3fQ.pqikpnfrtSttjAS6Z4A-zyUyzTypveMEllxCuHVjqpE";

        public const string InspectionsTable = "tbl_pulse_inspections";
        public const string CpuTable = "tbl_pulse_cpu_info";
        public const string MemoryTable = "tbl_pulse_memory_info";
        public const string StorageTable = "tbl_pulse_storage_info";
    }
}
