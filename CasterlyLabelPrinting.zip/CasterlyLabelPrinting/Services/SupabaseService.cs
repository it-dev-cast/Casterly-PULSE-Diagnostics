using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using CasterlyLabelPrinting.Models;

namespace CasterlyLabelPrinting.Services
{
    /// <summary>
    /// Talks to Supabase's auto-generated PostgREST API to look up inspection
    /// records (tbl_pulse_inspections) and their related hardware detail rows
    /// (tbl_pulse_cpu_info / tbl_pulse_memory_info / tbl_pulse_storage_info).
    /// </summary>
    public class SupabaseService
    {
        private readonly HttpClient _http;

        public SupabaseService()
        {
            _http = new HttpClient
            {
                BaseAddress = new Uri(SupabaseConfig.SupabaseUrl.TrimEnd('/') + "/rest/v1/"),
                Timeout = TimeSpan.FromSeconds(20)
            };
            _http.DefaultRequestHeaders.Add("apikey", SupabaseConfig.ServiceRoleKey);
            _http.DefaultRequestHeaders.Add("Authorization", "Bearer " + SupabaseConfig.ServiceRoleKey);
        }

        private async Task<JsonElement> GetJsonArrayAsync(string relativeUrl)
        {
            using HttpResponseMessage resp = await _http.GetAsync(relativeUrl);
            string body = await resp.Content.ReadAsStringAsync();

            if (!resp.IsSuccessStatusCode)
                throw new ApplicationException($"Supabase request failed ({(int)resp.StatusCode}): {body}");

            using JsonDocument doc = JsonDocument.Parse(body);
            if (doc.RootElement.ValueKind != JsonValueKind.Array)
                throw new ApplicationException("Unexpected response from Supabase (expected a JSON array).");

            return doc.RootElement.Clone();
        }

        /// <summary>Distinct serial numbers containing <paramref name="query"/>, most recent first.</summary>
        public async Task<List<string>> SearchSerialNumbersAsync(string query, int limit = 10)
        {
            string q = Uri.EscapeDataString($"*{query}*");
            string url = $"{SupabaseConfig.InspectionsTable}?select=serial_number,inspection_timestamp" +
                         $"&serial_number=ilike.{q}&order=inspection_timestamp.desc&limit=50";
            JsonElement rows = await GetJsonArrayAsync(url);

            return rows.EnumerateArray()
                .Select(r => r.TryGetProperty("serial_number", out var v) ? v.GetString() : null)
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Distinct()
                .Take(limit)
                .ToList();
        }

        /// <summary>Distinct LOT names containing <paramref name="query"/>, most recent first.</summary>
        public async Task<List<string>> SearchLotNamesAsync(string query, int limit = 10)
        {
            string q = Uri.EscapeDataString($"*{query}*");
            string url = $"{SupabaseConfig.InspectionsTable}?select=lot_name,inspection_timestamp" +
                         $"&lot_name=ilike.{q}&order=inspection_timestamp.desc&limit=50";
            JsonElement rows = await GetJsonArrayAsync(url);

            return rows.EnumerateArray()
                .Select(r => r.TryGetProperty("lot_name", out var v) ? v.GetString() : null)
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Distinct()
                .Take(limit)
                .ToList();
        }

        /// <summary>The single most recent inspection row for an exact serial number, or null if none exists.</summary>
        public async Task<InspectionRow> GetLatestInspectionBySerialAsync(string serialNumber)
        {
            string q = Uri.EscapeDataString(serialNumber);
            string url = $"{SupabaseConfig.InspectionsTable}?select=*&serial_number=eq.{q}" +
                         "&order=inspection_timestamp.desc&limit=1";
            JsonElement rows = await GetJsonArrayAsync(url);

            List<JsonElement> list = rows.EnumerateArray().ToList();
            return list.Count == 0 ? null : InspectionRow.FromJson(list[0]);
        }

        /// <summary>Every inspection row for an exact LOT name (i.e. every unit inspected under that LOT).</summary>
        public async Task<List<InspectionRow>> GetInspectionsByLotAsync(string lotName)
        {
            string q = Uri.EscapeDataString(lotName);
            string url = $"{SupabaseConfig.InspectionsTable}?select=*&lot_name=eq.{q}&order=inspection_timestamp.asc";
            JsonElement rows = await GetJsonArrayAsync(url);

            return rows.EnumerateArray().Select(InspectionRow.FromJson).ToList();
        }

        /// <summary>
        /// Builds the full 7-field label data for one inspection, joining in
        /// CPU / memory / storage detail from their respective tables via the
        /// inspection's uuid.
        /// </summary>
        public async Task<LabelFieldData> BuildLabelFieldDataAsync(InspectionRow inspection)
        {
            string uuid = Uri.EscapeDataString(inspection.Uuid ?? "");

            string processor = "-";
            List<JsonElement> cpuRows = (await GetJsonArrayAsync(
                $"{SupabaseConfig.CpuTable}?select=model&uuid=eq.{uuid}&limit=1")).EnumerateArray().ToList();
            if (cpuRows.Count > 0 && cpuRows[0].TryGetProperty("model", out JsonElement cpuModel) &&
                cpuModel.ValueKind == JsonValueKind.String)
            {
                processor = cpuModel.GetString();
            }

            string memory = "-";
            List<JsonElement> memRows = (await GetJsonArrayAsync(
                $"{SupabaseConfig.MemoryTable}?select=size_mb,memory_type,is_empty&uuid=eq.{uuid}")).EnumerateArray().ToList();
            if (memRows.Count > 0)
            {
                long totalMb = 0;
                string memType = null;
                foreach (JsonElement m in memRows)
                {
                    bool isEmpty = m.TryGetProperty("is_empty", out JsonElement ie) && ie.ValueKind == JsonValueKind.True;
                    if (isEmpty) continue;

                    if (m.TryGetProperty("size_mb", out JsonElement sizeMb) && sizeMb.ValueKind == JsonValueKind.Number)
                        totalMb += sizeMb.GetInt64();

                    if (memType == null && m.TryGetProperty("memory_type", out JsonElement mt) && mt.ValueKind == JsonValueKind.String)
                        memType = mt.GetString();
                }
                if (totalMb > 0)
                    memory = $"{totalMb / 1024.0:0.#} GB{(string.IsNullOrEmpty(memType) ? "" : " " + memType)}";
            }

            string storageType = "-";
            string storageCapacity = "-";
            List<JsonElement> storageRows = (await GetJsonArrayAsync(
                $"{SupabaseConfig.StorageTable}?select=storage_type,size_gb&uuid=eq.{uuid}&order=drive_index.asc")).EnumerateArray().ToList();
            if (storageRows.Count > 0)
            {
                JsonElement first = storageRows[0];
                if (first.TryGetProperty("storage_type", out JsonElement st) && st.ValueKind == JsonValueKind.String)
                    storageType = st.GetString();
                if (first.TryGetProperty("size_gb", out JsonElement sg) && sg.ValueKind == JsonValueKind.Number)
                    storageCapacity = $"{Math.Round(sg.GetDouble())} GB";
            }

            return new LabelFieldData
            {
                Manufacturer = string.IsNullOrWhiteSpace(inspection.Manufacturer) ? "-" : inspection.Manufacturer,
                Model = string.IsNullOrWhiteSpace(inspection.Model) ? "-" : inspection.Model,
                SerialNo = string.IsNullOrWhiteSpace(inspection.SerialNumber) ? "-" : inspection.SerialNumber,
                Processor = string.IsNullOrWhiteSpace(processor) ? "-" : processor,
                Memory = memory,
                StorageType = string.IsNullOrWhiteSpace(storageType) ? "-" : storageType,
                StorageCapacity = storageCapacity
            };
        }
    }
}
