using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using CasterlyLabelPrinting.Models;

namespace CasterlyLabelPrinting.Services
{
    /// <summary>
    /// Parses a WageLabel-style ".yix" label design file into a LabelDesign
    /// we can render and print ourselves, without depending on the original
    /// label-editor software being installed at print time.
    /// </summary>
    public static class YixLabelParser
    {
        public static LabelDesign Load(string path)
        {
            if (!File.Exists(path))
                throw new FileNotFoundException($"Label design file not found: {path}", path);

            string raw = File.ReadAllText(path);

            // The embedded preview thumbnail is a large base64 PNG blob that we
            // don't need for layout purposes, so strip it before parsing.
            raw = Regex.Replace(raw, "<PreviewImage>.*?</PreviewImage>", "<PreviewImage/>", RegexOptions.Singleline);

            // Wrap in a synthetic root for parsing robustness (defensive against
            // stray trailing content some exports of this format can contain),
            // then use the first <Elabel> element, which holds the real design.
            XDocument doc = XDocument.Parse($"<Root>{raw}</Root>");
            XElement elabel = doc.Root?.Element("Elabel");
            if (elabel == null)
                throw new InvalidDataException("Not a recognized .yix label file (missing <Elabel> root element).");

            var design = new LabelDesign();

            XElement config = elabel.Element("LabelConfig");
            if (config != null)
            {
                // Format: "widthMM, heightMM|width100thInch, height100thInch"
                string labelSize = config.Element("LabelSize")?.Value ?? "";
                string[] parts = labelSize.Split('|');
                if (parts.Length == 2)
                {
                    string[] wh = parts[1].Split(',');
                    if (wh.Length == 2)
                    {
                        design.WidthHundredthInch = ParseFloat(wh[0]);
                        design.HeightHundredthInch = ParseFloat(wh[1]);
                    }
                }

                design.PreferredPrinterName = config.Element("PrinterName")?.Value?.Trim() ?? "";

                XElement dsConfig = config.Element("DataSourceConfigure")?.Element("DataSourceConfig");
                if (dsConfig != null)
                {
                    design.DataColumns = dsConfig.Element("Columns")?
                        .Elements("Item")
                        .Select(i => i.Value)
                        .ToList() ?? new List<string>();
                }
            }

            XElement drawItems = elabel.Element("DrawItems");
            if (drawItems != null)
            {
                foreach (XElement textEl in drawItems.Elements("Text"))
                {
                    var item = new LabelTextItem();

                    XElement font = textEl.Element("TextFont");
                    // Format: "FontFamily|SizePt|...|...|...|..."
                    string showFont = font?.Element("ShowFont")?.Value ?? "Arial|8|False|True|False|False";
                    string[] fontParts = showFont.Split('|');
                    item.FontFamily = fontParts.Length > 0 && !string.IsNullOrWhiteSpace(fontParts[0]) ? fontParts[0] : "Arial";
                    item.FontSizePt = fontParts.Length > 1 ? ParseFloat(fontParts[1]) : 8f;
                    item.Bold = string.Equals(font?.Element("FontBlod")?.Value, "True", StringComparison.OrdinalIgnoreCase);

                    XElement entity = textEl.Element("TextValue")?.Element("ValueTextEntity");
                    string textType = entity?.Element("TextType")?.Value ?? "Text";
                    string textValue = entity?.Element("TextValue")?.Value?.Trim() ?? "";
                    string dataSourceName = entity?.Element("DataSourceName")?.Value?.Trim() ?? "";

                    item.IsDataBound = string.Equals(textType, "DataSource", StringComparison.OrdinalIgnoreCase)
                        && !string.IsNullOrEmpty(dataSourceName);
                    item.DataSourceColumn = dataSourceName;
                    item.StaticText = textValue;

                    string rectStr = textEl.Element("TextRectangle")?.Value ?? "0,0,0,0";
                    string[] rectParts = rectStr.Split(',');
                    if (rectParts.Length == 4)
                    {
                        item.RectHundredthInch = new RectangleF(
                            ParseFloat(rectParts[0]),
                            ParseFloat(rectParts[1]),
                            ParseFloat(rectParts[2]),
                            ParseFloat(rectParts[3]));
                    }

                    string align = textEl.Element("TextAlignStyle")?.Value ?? "Center";
                    item.Alignment = align switch
                    {
                        "Left" => StringAlignment.Near,
                        "Right" => StringAlignment.Far,
                        _ => StringAlignment.Center
                    };

                    design.Items.Add(item);
                }
            }

            if (design.Items.Count == 0)
                throw new InvalidDataException("The label design contains no drawable text items.");

            return design;
        }

        private static float ParseFloat(string s)
        {
            return float.TryParse((s ?? "").Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float v) ? v : 0f;
        }
    }
}
