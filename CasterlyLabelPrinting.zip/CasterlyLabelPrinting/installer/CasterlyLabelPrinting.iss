; Inno Setup script for Casterly Label Printing.
;
; This produces a normal Windows installer .exe from the app's *published*
; output folder. Inno Setup (free) is required to compile this script:
; https://jrsoftware.org/isdl.php
;
; Steps:
;   1. Publish the app first (from the project folder):
;        dotnet publish -c Release -r win-x64 --self-contained true ^
;          -p:PublishSingleFile=true -o publish
;   2. Open this .iss file in Inno Setup Compiler and click Build,
;      OR run from the command line:
;        ISCC.exe CasterlyLabelPrinting.iss
;   3. The installer .exe is written to installer\Output\.

#define MyAppName "Casterly Label Printing"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Casterly"
#define MyAppExeName "CasterlyLabelPrinting.exe"
; Path to the "dotnet publish" output folder, relative to this .iss file.
#define PublishDir "..\publish"

[Setup]
AppId={{8F1E2C2E-8B7B-4B7E-9E7B-CASTERLYLBL}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputBaseFilename=CasterlyLabelPrintingSetup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
Source: "{#PublishDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
